export declare class CreditosModule {
}
