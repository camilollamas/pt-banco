export declare class CreateCreditoDto {
    readonly clienteId: string;
    readonly fechaDesembolso: string;
    readonly monto: number;
    readonly plazoMeses: number;
    readonly tasaInteres: number;
    readonly estado: string;
}
