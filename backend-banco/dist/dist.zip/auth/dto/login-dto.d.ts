export declare class LoginDto {
    readonly username: string;
    readonly password: string;
}
